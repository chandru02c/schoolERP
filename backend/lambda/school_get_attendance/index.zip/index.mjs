/**
 * File: backend/lambda/school_get_attendance/index.mjs
 * Lambda: school_get_attendance
 * Runtime: Node.js 22.x — ES Modules
 * Description: AWS Lambda handler for all Attendance & Holiday read actions (GET_DAILY_SHEET, GET_HISTORY, GET_CLASS_REPORT, etc.).
 */

import { dbQuery } from './db.mjs';

const CORS_HEADERS = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Credentials': 'true',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, org_id, Org_Id, ORG_ID, x-user-id, X-User-Id, Accept, Origin, X-Requested-With'
};

function respond(statusCode, success, message, data = null, error = null) {
    return {
        statusCode,
        headers: CORS_HEADERS,
        body: JSON.stringify({
            success,
            message,
            timestamp: new Date().toISOString(),
            ...(data !== null && { data }),
            ...(error !== null && { error })
        })
    };
}

const GET_ATTENDANCE_SQL = 'SELECT school.fn_get_attendance($1::VARCHAR, $2::BIGINT, $3::JSONB) AS result;';

export const handler = async (event) => {
    const method = (
        event.httpMethod ||
        event.requestContext?.http?.method ||
        'GET'
    ).toUpperCase();

    if (method === 'OPTIONS') {
        return respond(200, true, 'CORS preflight approved.');
    }

    const headers = event.headers || {};
    const queryParams = event.queryStringParameters || {};
    let body = {};

    if (event.body) {
        try {
            body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        } catch {}
    }

    const orgId = Number(
        headers['org_id'] ||
        headers['x-org-id'] ||
        headers['Org_Id'] ||
        headers['ORG_ID'] ||
        queryParams.org_id ||
        body.org_id ||
        event.requestContext?.authorizer?.claims?.['custom:org_id']
    );

    if (!orgId || orgId <= 0) {
        return respond(400, false, 'org_id is required.');
    }

    const action = (queryParams.action || body.action || 'GET_DAILY_SHEET').toUpperCase();
    const params = {
        ...queryParams,
        ...body,
        org_id: orgId
    };

    try {
        const result = await dbQuery(GET_ATTENDANCE_SQL, [action, orgId, JSON.stringify(params)]);
        if (!result) {
            return respond(404, false, 'No data found.');
        }
        const isSuccess = result.success !== false;
        return respond(isSuccess ? 200 : 400, isSuccess, result.message || 'Data retrieved successfully.', result);
    } catch (err) {
        console.error('[school_get_attendance] Error:', err);
        return respond(500, false, 'Internal database query error.', null, { details: err.message });
    }
};
