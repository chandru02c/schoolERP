/**
 * File: index.mjs
 * Lambda: school_calendar
 * Runtime: Node.js 22.x — ES Modules
 * Description: School Calendar API — retrieves holidays, exams, events, and academy schedules.
 *
 * Input:
 *   - org_id (required)
 *   - academy_id (optional, defaults to active academy)
 */

import { dbExecute } from './db.mjs';

const CORS_HEADERS = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Credentials': 'true',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, org_id, Org_Id, ORG_ID, x-user-id, X-User-Id, Accept, Origin, X-Requested-With'
};

function respond(statusCode, success, message, data = null, error = null) {
    return {
        statusCode,
        headers: CORS_HEADERS,
        body: JSON.stringify({
            success,
            message,
            timestamp: new Date().toISOString(),
            ...(data !== null && { data }),
            ...(error !== null && { error })
        })
    };
}

export const handler = async (event) => {
    const method = (event.httpMethod || event.requestContext?.http?.method || 'GET').toUpperCase();
    if (method === 'OPTIONS') return respond(200, true, 'CORS preflight approved.');

    const headers = event.headers || {};
    const queryParams = event.queryStringParameters || {};

    const orgId = Number(
        headers['org_id'] ||
        headers['Org_Id'] ||
        headers['ORG_ID'] ||
        queryParams.org_id ||
        queryParams.orgId ||
        0
    );

    if (!orgId || orgId <= 0) {
        return respond(400, false, 'Tenant organisation ID (org_id) is required.');
    }

    try {
        let academicYearId = Number(queryParams.academy_id || queryParams.academic_year_id || 0);
        if (!academicYearId) {
            const yRows = await dbExecute(
                `SELECT academic_year_id FROM school.academic_year WHERE org_id = $1 AND is_deleted = FALSE ORDER BY is_active DESC LIMIT 1;`,
                [orgId]
            );
            if (yRows.length > 0) academicYearId = Number(yRows[0].academic_year_id);
        }

        const eventsList = [];

        // 1. Fetch holidays from holiday_master
        const holidayRows = await dbExecute(
            `SELECT id, holiday_name, holiday_type, holiday_date, description
             FROM school.holiday_master
             WHERE org_id = $1 AND is_deleted = FALSE
             ORDER BY holiday_date ASC;`,
            [orgId]
        );

        if (holidayRows && holidayRows.length > 0) {
            holidayRows.forEach((h) => {
                const dateStr = typeof h.holiday_date === 'string'
                    ? h.holiday_date.split('T')[0]
                    : new Date(h.holiday_date).toISOString().split('T')[0];
                eventsList.push({
                    id: `hol-${h.id}`,
                    title: h.holiday_name,
                    date: dateStr,
                    type: 'holiday',
                    description: h.description || `${h.holiday_type || 'School'} Holiday`,
                    time: 'All Day',
                    location: 'Campus Wide'
                });
            });
        }

        // 2. Fetch academic calendar events
        const calRows = await dbExecute(
            `SELECT calendar_id, title, event_type, start_date, end_date, description, is_holiday
             FROM school.academic_calendar
             WHERE org_id = $1 AND ($2 = 0 OR academic_year_id = $2) AND is_deleted = FALSE
             ORDER BY start_date ASC;`,
            [orgId, academicYearId]
        );

        if (calRows && calRows.length > 0) {
            calRows.forEach((c) => {
                const dateStr = typeof c.start_date === 'string'
                    ? c.start_date.split('T')[0]
                    : new Date(c.start_date).toISOString().split('T')[0];

                let evType = 'event';
                const rawType = (c.event_type || '').toUpperCase();
                if (c.is_holiday || rawType === 'HOLIDAY') evType = 'holiday';
                else if (rawType === 'EXAM') evType = 'exam';
                else if (rawType === 'PTM') evType = 'meeting';

                eventsList.push({
                    id: `cal-${c.calendar_id}`,
                    title: c.title,
                    date: dateStr,
                    type: evType,
                    description: c.description || c.title,
                    time: '09:00 AM - 04:00 PM',
                    location: 'Main Campus'
                });
            });
        }

        // 3. Fetch general school events from event_master
        const evRows = await dbExecute(
            `SELECT event_id, event_title, event_type, event_start_date, description, location
             FROM school.event_master
             WHERE org_id = $1 AND is_deleted = FALSE
             ORDER BY event_start_date ASC LIMIT 50;`,
            [orgId]
        );

        if (evRows && evRows.length > 0) {
            evRows.forEach((e) => {
                const dateStr = typeof e.event_start_date === 'string'
                    ? e.event_start_date.split('T')[0]
                    : new Date(e.event_start_date).toISOString().split('T')[0];

                eventsList.push({
                    id: `ev-${e.event_id}`,
                    title: e.event_title,
                    date: dateStr,
                    type: 'event',
                    description: e.description || e.event_title,
                    time: '10:00 AM - 01:00 PM',
                    location: e.location || 'School Auditorium'
                });
            });
        }

        // 4. Default fallback events if tenant has no calendar records yet
        if (eventsList.length === 0) {
            const todayStr = new Date().toISOString().split('T')[0];
            eventsList.push(
                {
                    id: 'sample-1',
                    title: 'Mid-Term Examinations',
                    date: todayStr,
                    type: 'exam',
                    description: 'Term-1 Evaluation Series for Grade 9 & 10',
                    time: '09:00 AM - 12:00 PM',
                    location: 'Examination Hall A'
                },
                {
                    id: 'sample-2',
                    title: 'Staff Curriculum Meeting',
                    date: todayStr,
                    type: 'meeting',
                    description: 'Quarterly review of syllabus completion and grading',
                    time: '03:30 PM - 04:30 PM',
                    location: 'Faculty Conference Room'
                }
            );
        }

        // Sort events by date ascending
        eventsList.sort((a, b) => a.date.localeCompare(b.date));

        return respond(200, true, 'Calendar events retrieved successfully.', {
            academic_year_id: academicYearId,
            events: eventsList
        });

    } catch (err) {
        console.error('[school_calendar] Error:', err);
        return respond(500, false, 'Internal server error while fetching calendar events.', null, { details: err.message });
    }
};
