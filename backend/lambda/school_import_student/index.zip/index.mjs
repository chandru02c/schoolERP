/**
 * File: index.mjs
 * Lambda: school_import_student
 * Runtime: Node.js 22.x — ES Modules
 * Description: AWS Lambda Handler for importing approved admissions into Student Master.
 *              Routes POST → importStudent().
 *              Only validates org_id from request headers.
 *              All business validation handled by PostgreSQL procedure sp_save_student.
 */

import { dbExecute } from './db.mjs';

// ─── CORS / Response Headers ──────────────────────────────────────────────────

const CORS_HEADERS = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Credentials': 'true',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, org_id, Org_Id, ORG_ID, x-user-id, X-User-Id, Accept, Origin, X-Requested-With'
};

// ─── Response Builder ─────────────────────────────────────────────────────────

function respond(statusCode, success, message, data = null, error = null) {
    return {
        statusCode,
        headers: CORS_HEADERS,
        body: JSON.stringify({
            success,
            message,
            timestamp: new Date().toISOString(),
            ...(data !== null && { data }),
            ...(error !== null && { error })
        })
    };
}

// ─── SQL ──────────────────────────────────────────────────────────────────────

const SAVE_STUDENT_SQL = `CALL school.sp_save_student($1, $2, $3, $4::jsonb, $5, NULL);`;

// ─── Feature Functions ────────────────────────────────────────────────────────

/**
 * Imports an approved admission into the student master table.
 * @param {number} orgId  - Tenant organisation ID.
 * @param {Object} body   - Request body containing admission_id and optional academic overrides.
 * @param {number} userId - Authenticated user ID.
 * @returns {Promise<Object|null>}
 */
async function importStudent(orgId, body, userId) {
    const values = ['IMPORT', 0, orgId, JSON.stringify(body || {}), userId || 0];
    return await dbExecute(SAVE_STUDENT_SQL, values, orgId);
}

/**
 * Imports multiple approved admissions in a batch.
 * @param {number} orgId  - Tenant organisation ID.
 * @param {Array}  items  - Array of import items or admission IDs.
 * @param {number} userId - Authenticated user ID.
 * @returns {Promise<Object>} Summary of imported records and errors.
 */
async function batchImportStudents(orgId, items, userId) {
    const results = [];
    const errors = [];

    for (const item of items) {
        const payload = typeof item === 'number' ? { admission_id: item } : item;
        try {
            const res = await importStudent(orgId, payload, userId);
            if (res?.success) {
                results.push(res.data);
            } else {
                errors.push({
                    admission_id: payload.admission_id,
                    error_code: res?.error_code || 'ERR_IMPORT_FAILED',
                    message: res?.message || 'Failed to import admission.'
                });
            }
        } catch (err) {
            errors.push({
                admission_id: payload.admission_id,
                error_code: 'ERR_INTERNAL_DB',
                message: err.message
            });
        }
    }

    return {
        total_requested: items.length,
        total_success: results.length,
        total_failed: errors.length,
        imported_students: results,
        failures: errors
    };
}

// ─── Lambda Handler ───────────────────────────────────────────────────────────

export const handler = async (event) => {
    const method = (
        event.httpMethod ||
        event.requestContext?.http?.method ||
        'POST'
    ).toUpperCase();

    // CORS preflight
    if (method === 'OPTIONS') {
        return respond(200, true, 'CORS preflight approved.');
    }

    // ── org_id validation ──────────────────────────────────────────────────
    const headers = event.headers || {};
    const orgId = Number(
        headers['org_id'] ||
        headers['Org_Id'] ||
        headers['ORG_ID'] ||
        event.requestContext?.authorizer?.claims?.['custom:org_id']
    );

    if (!orgId || orgId <= 0) {
        return respond(400, false, 'org_id header is required.');
    }

    const userId = Number(
        headers['x-user-id'] ||
        headers['X-User-Id'] ||
        event.requestContext?.authorizer?.claims?.['custom:user_id'] ||
        0
    );

    // ── Parse body ─────────────────────────────────────────────────────────
    let body = {};
    if (event.body) {
        try {
            body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        } catch {
            return respond(400, false, 'Invalid JSON in request body.');
        }
    }

    // ── HTTP Method Routing ────────────────────────────────────────────────
    try {
        if (method === 'POST') {
            // Check if batch import requested
            if (Array.isArray(body.admission_ids) || Array.isArray(body.items)) {
                const items = body.admission_ids || body.items;
                const batchResult = await batchImportStudents(orgId, items, userId);

                const isAllFailed = batchResult.total_success === 0 && batchResult.total_requested > 0;
                return respond(
                    isAllFailed ? 400 : 200,
                    !isAllFailed,
                    `Batch import completed. Successfully imported: ${batchResult.total_success}, Failed: ${batchResult.total_failed}`,
                    batchResult
                );
            }

            // Single student import
            const result = await importStudent(orgId, body, userId);

            if (!result?.success) {
                return respond(400, false,
                    result?.message || 'Failed to import student from admission.',
                    null,
                    { code: result?.error_code || 'ERR_IMPORT_FAILED' }
                );
            }

            return respond(201, true, result.message, result.data);
        }

        return respond(405, false, `Method ${method} not allowed.`);

    } catch (err) {
        console.error('[school_import_student] Unhandled error:', err);
        return respond(500, false, 'Internal server error.', null, { details: err.message });
    }
};
