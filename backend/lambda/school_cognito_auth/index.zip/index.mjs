/**
 * File: index.mjs
 * Lambda: school_cognito_auth
 * Runtime: Node.js 22.x — ES Modules
 * Description: AWS Lambda Handler for post-Cognatio login role validation & Cognatio user linking.
 *              Routes:
 *                1. POST /auth/cognito-validate -> Validates user identity & role against teacher master.
 *                2. POST /teacher/cognito-link  -> Links Cognatio User ID & email to teacher profile.
 */

import { dbQuery, dbExecute } from './db.mjs';

const CORS_HEADERS = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Credentials': 'true',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, org_id, Org_Id, ORG_ID, x-user-id, X-User-Id, Accept, Origin, X-Requested-With'
};

function respond(statusCode, success, message, data = null, error = null, extra = {}) {
    return {
        statusCode,
        headers: CORS_HEADERS,
        body: JSON.stringify({
            success,
            message,
            timestamp: new Date().toISOString(),
            ...(data !== null && { data }),
            ...(error !== null && { error }),
            ...extra
        })
    };
}

const VALIDATE_USER_SQL = `
    SELECT school.fn_validate_cognito_user(
        $1::VARCHAR,
        $2::VARCHAR,
        $3::VARCHAR,
        $4::BIGINT
    ) AS result;
`;

const LINK_TEACHER_SQL = `
    UPDATE school.teacher_details
    SET cognatio_user_id = $1,
        cognito_user_id = $1,
        cognatio_email = $2,
        login_enabled = TRUE,
        updated_at = CURRENT_TIMESTAMP
    WHERE teacher_id = $3
      AND org_id = $4
      AND is_deleted = FALSE
    RETURNING teacher_id, org_id, teacher_code, full_name, email, user_type, cognatio_user_id, cognatio_email;
`;

export const handler = async (event) => {
    const method = (
        event.httpMethod ||
        event.requestContext?.http?.method ||
        'POST'
    ).toUpperCase();

    if (method === 'OPTIONS') {
        return respond(200, true, 'CORS preflight approved.');
    }

    const path = (event.path || event.requestContext?.http?.path || '').toLowerCase();
    const headers = event.headers || {};
    const headerOrgId = Number(
        headers['org_id'] ||
        headers['Org_Id'] ||
        headers['ORG_ID'] ||
        event.requestContext?.authorizer?.claims?.['custom:org_id'] ||
        0
    );

    let body = {};
    if (event.body) {
        try {
            body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        } catch {
            return respond(400, false, 'Invalid JSON in request body.');
        }
    }

    try {
        // ── 1. ROUTE: POST /teacher/cognito-link (Link Cognatio User ID to Teacher) ──
        if (path.includes('/cognito-link') || path.includes('/cognatio-link') || body.action === 'link') {
            const teacherId = Number(body.teacher_id || body.teacherId || body.id);
            const orgId = Number(body.org_id || headerOrgId);
            const cognatioUserId = String(body.cognatio_user_id || body.cognito_user_id || '').trim();
            const cognatioEmail = String(body.cognatio_email || body.email || '').trim();

            if (!teacherId || teacherId <= 0) {
                return respond(400, false, 'teacher_id is required.');
            }
            if (!orgId || orgId <= 0) {
                return respond(400, false, 'org_id is required.');
            }
            if (!cognatioUserId) {
                return respond(400, false, 'cognatio_user_id is required.');
            }

            const result = await dbExecute(LINK_TEACHER_SQL, [cognatioUserId, cognatioEmail || null, teacherId, orgId]);
            if (!result || result.length === 0) {
                return respond(404, false, 'Teacher record not found or does not belong to tenant.');
            }

            return respond(200, true, 'Cognatio user linked successfully.', result[0]);
        }

        // ── 2. ROUTE: POST /auth/cognito-validate (Validate Login Role & User) ──
        const cognitoUserId = String(body.cognito_user_id || body.cognatio_user_id || body.sub || '').trim();
        const email = String(body.email || '').trim();
        const selectedRole = String(body.selected_role || body.selectedRole || 'ADMIN').trim().toUpperCase();
        const orgId = Number(body.org_id || headerOrgId) || null;

        if (!cognitoUserId && !email) {
            return respond(400, false, 'Either cognito_user_id or email is required.');
        }

        const validation = await dbQuery(VALIDATE_USER_SQL, [
            cognitoUserId || null,
            email || null,
            selectedRole,
            orgId
        ]);

        if (!validation) {
            return respond(500, false, 'Database validation function returned empty response.');
        }

        if (!validation.success || !validation.authorized) {
            return respond(403, false, validation.message || 'Authorization failed.', null, {
                code: validation.error_code || 'ERR_UNAUTHORIZED',
                user_type: validation.user_type,
                selected_role: validation.selected_role
            });
        }

        return respond(200, true, validation.message, validation.user, null, {
            redirect_url: validation.redirect_url,
            authorized: true,
            org_id: validation.user?.org_id
        });

    } catch (err) {
        console.error('[school_cognito_auth] Error:', err);
        return respond(500, false, 'Internal server error.', null, { details: err.message });
    }
};
