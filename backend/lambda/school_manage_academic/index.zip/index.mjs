/**
 * File: index.mjs
 * Lambda: school_manage_academic
 * Runtime: Node.js 22.x — ES Modules
 * Description: Unified AWS Lambda handler for all Academic Management write actions.
 */

import { dbExecute } from './db.mjs';

const CORS_HEADERS = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Credentials': 'true',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, org_id, Org_Id, ORG_ID, x-user-id, X-User-Id, Accept, Origin, X-Requested-With'
};

function respond(statusCode, success, message, data = null, error = null) {
    return {
        statusCode,
        headers: CORS_HEADERS,
        body: JSON.stringify({
            success,
            message,
            timestamp: new Date().toISOString(),
            ...(data !== null && { data }),
            ...(error !== null && { error })
        })
    };
}

const MANAGE_ACADEMIC_SQL = `
    CALL school.sp_manage_academic(
        $1::VARCHAR,
        $2::BIGINT,
        $3::JSONB,
        $4::BIGINT,
        NULL
    );
`;

export const handler = async (event) => {
    const method = (
        event.httpMethod ||
        event.requestContext?.http?.method ||
        'POST'
    ).toUpperCase();

    // CORS Preflight
    if (method === 'OPTIONS') {
        return respond(200, true, 'CORS preflight approved.');
    }

    let body = {};
    if (event.body) {
        try {
            body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        } catch {
            return respond(400, false, 'Invalid JSON in request body.');
        }
    }

    const headers = event.headers || {};
    const orgId = Number(
        headers['org_id'] ||
        headers['Org_Id'] ||
        headers['ORG_ID'] ||
        body.org_id ||
        event.queryStringParameters?.org_id ||
        event.requestContext?.authorizer?.claims?.['custom:org_id']
    );

    if (!orgId || orgId <= 0) {
        return respond(400, false, 'Tenant organisation ID (org_id) is required in header or body.');
    }

    const userId = Number(
        headers['x-user-id'] ||
        headers['X-User-Id'] ||
        body.user_id ||
        body.teacher_id ||
        event.requestContext?.authorizer?.claims?.['custom:user_id'] ||
        0
    );

    const action = (body.action || event.queryStringParameters?.action || '').toUpperCase();
    if (!action) {
        return respond(400, false, 'Action is required in request payload (e.g. CREATE_YEAR, CREATE_SET, ASSIGN_CLASS_TEACHER, etc.).');
    }

    try {
        const values = [
            action,
            orgId,
            JSON.stringify(body),
            userId
        ];

        const result = await dbExecute(MANAGE_ACADEMIC_SQL, values, orgId);

        if (!result?.success) {
            return respond(400, false,
                result?.message || 'Failed to process academic request.',
                null,
                { code: result?.error_code || 'ERR_OPERATION_FAILED' }
            );
        }

        return respond(200, true, result.message, result.data || null);

    } catch (err) {
        console.error('[school_manage_academic] Error:', err);
        return respond(500, false, 'Internal server error processing academic action.', null, { details: err.message });
    }
};
